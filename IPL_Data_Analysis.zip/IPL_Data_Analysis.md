
# IPL - Exploratory Data Analysis | Data Science | Python | AI

### By Santosh Dogra

#### Submitted to INSAID

## Table of Contents

1. [Problem Statement](#section1)<br>
2. [Data Loading and Description](#section2)
3. [Data Profiling](#section3)
    - 3.1 [Understanding the Dataset](#section301)<br/>
    - 3.2 [Pre Profiling](#section302)<br/>
    - 3.3 [Preprocessing](#section303)<br/>
    - 3.4 [Post Profiling](#section304)<br/>
4. [Seeking Answers (World Of #Ws) ](#section4)
    - 4.1 [How many matches being played in each season?](#section401)<br/>
    - 4.2 [Which Team had won by maximum runs? (Overall & 2018)](#section402)<br/>
    - 4.3 [Which Team had won by maximum wickets? (Overall & 2018)](#section403)<br/>
    - 4.4 [Which Team had won by (closest margin) minimum runs?(Overall & 2018)](#section404)<br/>
    - 4.5 [Which Team had won by minimum wickets? (Overall & 2018)](#section405)<br/>
    - 4.6 [Which Season had most matches?](#section406)<br/>
    - 4.7 [Which City is most Popular in IPL?](#section407)<br/>
    - 4.8 [Which Stadium is getting Home Matches in IPL?](#section408)<br/>
    - 4.9 [Which Team is most successful in IPL](#section409)<br/>
    - 4.10 [How is Team Win Stats Standings YOY](#section410)<br/>
    - 4.11 [Highest Win % Market Share in IPL](#section411)<br/>
    - 4.12 [Top player of the match Winners](#section412)<br/>
    - 4.13 [Top player of the match Winners - 2018 & 2017](#section413)<br/>
    - 4.14 [Does Winning the Toss helps in Winning matches?](#section414)<br/>
    - 4.15 [Did Choosing to Bat first or Field First helped in Toss winning](#section415)<br/>    
    - 4.16 [Match Winner is Toss Winner - Overall.](#section416)<br/>
    - 4.17 [Which Team Chose What - On Winning the Toss](#section417)<br/>
    - 4.18 [Analysing Impact of Toss Winning team Season By Season](#section418)<br/> 
    - 4.19 [Who is Most Trusted Umpire in IPL](#section419)<br/>
    - 4.20 [Which Venue did Weather Affected Most](#section420)<br/>
    - 4.21 [Best Stadium to Chase and Win](#section421)<br/>    
    - 4.22 [Best Team in Best Chasing Venue](#section422)<br/>
    - 4.23 [Best Stadium to Bat first and Win](#section423)<br/>
    - 4.24 [Best team in Best Defending Venue](#section424)<br/>    
    - 4.25 [Which Team is Best in Defending](#section425)<br/>
    - 4.26 [Which Team is Best in Chasing](#section426)<br/>    
    - 4.27 [Home Turf Advantage - Team wins in home city vs other cities](#section427)<br/> 

5. [Conclusions](#section5)<br/>  

### 1. Problem Statement

In this we will analyse the IPL Data which was provided in Github link.
The notebooks explores the basic use of __Pandas__ and will cover the basic commands of __Exploratory Data Analysis(EDA)__ which includes __cleaning__, __munging__, __combining__, __reshaping__, __slicing__, __dicing__, and __transforming data__ for analysis purpose.

* __Exploratory Data Analysis__ <br/>
We will Understand the data by EDA and derive simple models with Pandas as baseline.
EDA ia a critical and first step in analyzing the data and we do this for below reasons :
    - Finding patterns in Data
    - Determining relationships in Data
    - Checking of assumptions
    - Preliminary selection of appropriate models
     


![ipl003%20-%20Copy.jpg](attachment:ipl003%20-%20Copy.jpg)
### 2. Data Loading and Description



- The dataset consists of the information about matches played in IPL season with data of wins, toss, umpire, venue etc.
- The dataset comprises of __696 observations of 18 columns__. Below is a table showing names of all the columns and their description.

| Column Name   | Description                                               |
| ------------- |:-------------                                            :| 
|id                | Unique Match Id 
|season            | Year of Match 
|city              | City where the match occurred
|date              | Date of match played 
|team1             | Team 1 Name
|team2             | Team 2 Name
|toss_winner       |  Team who won the toss
|toss_decision     | Decision of Toss Winner
|result            | Result of the match
|dl_applied        | Duckworth Luis method being applied or not
|winner            | Winner of the match
|win_by_runs       | Match won by defending
|win_by_wickets    | Match won by chasing
|player_of_match   | Player who won man of the match award
|venue             | Stadium Name
|umpire1           | Umpire 1 Name
|umpire2           | Umpire 2 Name
|umpire3           | Umpire 3 Name


### 2.1 IPL - The Prayer of Cricket Religion Country

The Indian Premier League (IPL) is a professional Twenty20 cricket league in India contested during April and May of every year by teams representing 8 Indian cities and some states.The league was founded by the Board of Control for Cricket in India (BCCI) in 2008, and is regarded as the brainchild of Lalit Modi, the founder and former commissioner of the league. IPL has an exclusive window in ICC Future Tours Programme.

The IPL is the most-attended cricket league in the world and in 2014 ranked sixth by average attendance among all sports leagues.In 2010, the IPL became the first sporting event in the world to be broadcast live on YouTube. The brand value of IPL in 2018 was US$6.3 billion, according to Duff & Phelps. According to BCCI, the 2015 IPL season contributed ₹11.5 billion (US$182 million) to the GDP of the Indian economy

There have been eleven seasons of the IPL tournament. The current IPL title holders are the Chennai Super Kings, who won the 2018 season.


### 2.2 How has IPL helped cricket in India & World?
The IPL has offered financial security to a wide range of cricketers. It has changed cricket’s commercial scenario so much that it has inspired the mushrooming of leagues across the cricket-playing world. Even in India, other sporting associations feel empowered to have their own leagues, leading to a win-win situation for athletes and fans.


***importing packages***

*We will Load Library for simplification of our life at beginning itself*


```python
import numpy as np # Implemennts milti-dimensional array and matrices
import pandas as pd # data manipulation, processing, CSV file I/O (e.g. pd.read_csv) and analysis
import pandas_profiling 
import matplotlib.pyplot as plt #visualization, plotting library for python programming langauage and it's numberical mathematics extension NumPy
import seaborn as sns #modern visualization 
import matplotlib as mat #visualization, provides a high level interface for drawing attractice and informative statistical graphics.
import bokeh #visualization
%matplotlib inline
sns.set()

from subprocess import check_output
```

We will define the theme and data size


```python
sns.set_style("darkgrid")
plt.rcParams['figure.figsize'] = (14, 8)
```

## 3. Data Profiling

- In the upcoming sections we will first __understand our dataset__ using various pandas functionalities.
- Then with the help of __pandas profiling__ we will find which columns of our dataset need preprocessing.
- In __preprocessing__ we will deal with erronous and missing values of columns. 
- Again we will do __pandas profiling__ to see how preprocessing have transformed our dataset.

### 3.1 Data Set Reading and Understanding Basic Structure & info**


To gain insights from data we must look into each aspect of it very carefully. We will start with observing few rows and columns of data both from the starting and from the end.
We will import the data now and read the heading and couple of rows


```python
IPL = pd.read_csv("https://raw.githubusercontent.com/insaid2018/Term-1/master/Data/Projects/matches.csv") # Importing  dataset using pd.read_csv
IPL.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>season</th>
      <th>city</th>
      <th>date</th>
      <th>team1</th>
      <th>team2</th>
      <th>toss_winner</th>
      <th>toss_decision</th>
      <th>result</th>
      <th>dl_applied</th>
      <th>winner</th>
      <th>win_by_runs</th>
      <th>win_by_wickets</th>
      <th>player_of_match</th>
      <th>venue</th>
      <th>umpire1</th>
      <th>umpire2</th>
      <th>umpire3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2017</td>
      <td>Hyderabad</td>
      <td>2017-04-05</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>Royal Challengers Bangalore</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Sunrisers Hyderabad</td>
      <td>35</td>
      <td>0</td>
      <td>Yuvraj Singh</td>
      <td>Rajiv Gandhi International Stadium, Uppal</td>
      <td>AY Dandekar</td>
      <td>NJ Llong</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2017</td>
      <td>Pune</td>
      <td>2017-04-06</td>
      <td>Mumbai Indians</td>
      <td>Rising Pune Supergiant</td>
      <td>Rising Pune Supergiant</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Rising Pune Supergiant</td>
      <td>0</td>
      <td>7</td>
      <td>SPD Smith</td>
      <td>Maharashtra Cricket Association Stadium</td>
      <td>A Nand Kishore</td>
      <td>S Ravi</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2017</td>
      <td>Rajkot</td>
      <td>2017-04-07</td>
      <td>Gujarat Lions</td>
      <td>Kolkata Knight Riders</td>
      <td>Kolkata Knight Riders</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Kolkata Knight Riders</td>
      <td>0</td>
      <td>10</td>
      <td>CA Lynn</td>
      <td>Saurashtra Cricket Association Stadium</td>
      <td>Nitin Menon</td>
      <td>CK Nandan</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2017</td>
      <td>Indore</td>
      <td>2017-04-08</td>
      <td>Rising Pune Supergiant</td>
      <td>Kings XI Punjab</td>
      <td>Kings XI Punjab</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Kings XI Punjab</td>
      <td>0</td>
      <td>6</td>
      <td>GJ Maxwell</td>
      <td>Holkar Cricket Stadium</td>
      <td>AK Chaudhary</td>
      <td>C Shamshuddin</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2017</td>
      <td>Bangalore</td>
      <td>2017-04-08</td>
      <td>Royal Challengers Bangalore</td>
      <td>Delhi Daredevils</td>
      <td>Royal Challengers Bangalore</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Royal Challengers Bangalore</td>
      <td>15</td>
      <td>0</td>
      <td>KM Jadhav</td>
      <td>M Chinnaswamy Stadium</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



Checking getting basic *info*


```python
IPL.shape
IPL.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 696 entries, 0 to 695
    Data columns (total 18 columns):
    id                 696 non-null int64
    season             696 non-null int64
    city               689 non-null object
    date               696 non-null object
    team1              696 non-null object
    team2              696 non-null object
    toss_winner        696 non-null object
    toss_decision      696 non-null object
    result             696 non-null object
    dl_applied         696 non-null int64
    winner             693 non-null object
    win_by_runs        696 non-null int64
    win_by_wickets     696 non-null int64
    player_of_match    693 non-null object
    venue              696 non-null object
    umpire1            695 non-null object
    umpire2            695 non-null object
    umpire3            60 non-null object
    dtypes: int64(5), object(13)
    memory usage: 98.0+ KB
    

Moving one level up, let’s perform a simple summary statistics using the method describe().




```python
IPL.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>season</th>
      <th>dl_applied</th>
      <th>win_by_runs</th>
      <th>win_by_wickets</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>696.000000</td>
      <td>696.000000</td>
      <td>696.000000</td>
      <td>696.000000</td>
      <td>696.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>974.103448</td>
      <td>2012.965517</td>
      <td>0.027299</td>
      <td>13.472701</td>
      <td>3.349138</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2143.239623</td>
      <td>3.069266</td>
      <td>0.163070</td>
      <td>23.607994</td>
      <td>3.411398</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2008.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>174.750000</td>
      <td>2010.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>348.500000</td>
      <td>2013.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>522.250000</td>
      <td>2016.000000</td>
      <td>0.000000</td>
      <td>19.000000</td>
      <td>6.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>7953.000000</td>
      <td>2018.000000</td>
      <td>1.000000</td>
      <td>146.000000</td>
      <td>10.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
IPL.isnull().sum()
```




    id                   0
    season               0
    city                 7
    date                 0
    team1                0
    team2                0
    toss_winner          0
    toss_decision        0
    result               0
    dl_applied           0
    winner               3
    win_by_runs          0
    win_by_wickets       0
    player_of_match      3
    venue                0
    umpire1              1
    umpire2              1
    umpire3            636
    dtype: int64



From the above output we can see that __city__, __winner__, __player_of_the_match__ and __umpire3__ columns contains __maximum null values__. We will see how to deal with them.

### 3.2 Pre Profiling

- By pandas profiling, an __interactive HTML report__ gets generated which contins all the information about the columns of the dataset, like the __counts and type__ of each _column_. Detailed information about each column, __coorelation between different columns__ and a sample of dataset.<br/>
- It gives us __visual interpretation__ of each column in the data.
- _Spread of the data_ can be better understood by the distribution plot. 
- _Grannular level_ analysis of each column.


```python
profile = pandas_profiling.ProfileReport(IPL)
profile.to_file(outputfile="IPL_Profile.html")
```

Here, we have done Pandas Profiling before preprocessing our dataset, so we have named the html file as __IPL_Profile.html__. Take a look at the file and see what useful insight you can develop from it. <br/>
Now we will process our data to better understand it.


**How many matches we’ve got in the dataset?
****bold text**

Its been noted that each ID counts the each variable, while each ID is nothing but matches. Total no of matches which will be analysed in data set is 


```python
IPL['id'].count()
```




    696



### How many seasons we’ve got in the dataset?


Lets seasons included in data sets. We will see how many unique season exist in dataset


```python
IPL['season'].unique()

```




    array([2017, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2018],
          dtype=int64)




```python
len(IPL['season'].unique()) 
```




    11



### Data Break Up


```python
IPL2008 = IPL[IPL['season'] == 2008]
IPL2009 = IPL[IPL['season'] == 2009]
IPL2010 = IPL[IPL['season'] == 2010]
IPL2011 = IPL[IPL['season'] == 2011]
IPL2012 = IPL[IPL['season'] == 2012]
IPL2013 = IPL[IPL['season'] == 2013]
IPL2014 = IPL[IPL['season'] == 2014]
IPL2015 = IPL[IPL['season'] == 2015]
IPL2016 = IPL[IPL['season'] == 2016]
IPL2017 = IPL[IPL['season'] == 2017]
IPL2018 = IPL[IPL['season'] == 2018]
```

### Heatmap


```python
f=IPL.corr()
plt.figure(figsize=(12,10))
sns.heatmap(f,annot=True,cmap='coolwarm')
plt.show()
```


![png](output_39_0.png)


There is negative correlataion between **win_by_runs** & **win_by_wickets**, and thats quite obvious, as one value will be 0 and they both can't co-exist together.

## 4. Seeking Answers (World Of #Ws) 

### 4.1 How many matches being played in each season**

Lets check matches played each season


```python

plt.title('Matches in Each Season')
plt.xlabel('x')
plt.ylabel('y') 
sns.countplot(x='season', data=IPL)


```




    <matplotlib.axes._subplots.AxesSubplot at 0x1c16bf864e0>




![png](output_44_1.png)


### 4.2 Which Team had won by maximum runs?**
#### Overall & 2018

Lets get the details of the match which has been won with maximum runs


```python
IPL.iloc[IPL['win_by_runs'].idxmax()]

```




    id                               44
    season                         2017
    city                          Delhi
    date                     2017-05-06
    team1                Mumbai Indians
    team2              Delhi Daredevils
    toss_winner        Delhi Daredevils
    toss_decision                 field
    result                       normal
    dl_applied                        0
    winner               Mumbai Indians
    win_by_runs                     146
    win_by_wickets                    0
    player_of_match         LMP Simmons
    venue              Feroz Shah Kotla
    umpire1                 Nitin Menon
    umpire2                   CK Nandan
    umpire3                         NaN
    Name: 43, dtype: object




```python
IPL.iloc[IPL['win_by_runs'].idxmax()]['winner']
```




    'Mumbai Indians'




```python
IPL2018.iloc[IPL['win_by_runs'].idxmax()]
```




    id                                   7937
    season                               2018
    city                               Indore
    date                             12/05/18
    team1               Kolkata Knight Riders
    team2                     Kings XI Punjab
    toss_winner               Kings XI Punjab
    toss_decision                       field
    result                             normal
    dl_applied                              0
    winner              Kolkata Knight Riders
    win_by_runs                            31
    win_by_wickets                          0
    player_of_match                 SP Narine
    venue              Holkar Cricket Stadium
    umpire1                          O Nandan
    umpire2             Virender Kumar Sharma
    umpire3                    Bruce Oxenford
    Name: 679, dtype: object



***Overall Win By Runs = Mumbai Indians (146 Runs)***


***2018 Win By Runs = Kolkata Knight Riders (31 Runs) ***

### 4.3 Which Team had won by maximum wickets?
#### Overall & 2018

Similarly we can check which team has won by maximum wickets and details of that match


```python
IPL.iloc[IPL['win_by_wickets'].idxmax()]
```




    id                                                      3
    season                                               2017
    city                                               Rajkot
    date                                           2017-04-07
    team1                                       Gujarat Lions
    team2                               Kolkata Knight Riders
    toss_winner                         Kolkata Knight Riders
    toss_decision                                       field
    result                                             normal
    dl_applied                                              0
    winner                              Kolkata Knight Riders
    win_by_runs                                             0
    win_by_wickets                                         10
    player_of_match                                   CA Lynn
    venue              Saurashtra Cricket Association Stadium
    umpire1                                       Nitin Menon
    umpire2                                         CK Nandan
    umpire3                                               NaN
    Name: 2, dtype: object




```python
IPL2018.iloc[IPL['win_by_wickets'].idxmax()]
```




    id                                        7896
    season                                    2018
    city                                   Kolkata
    date                                  08/04/18
    team1              Royal Challengers Bangalore
    team2                    Kolkata Knight Riders
    toss_winner              Kolkata Knight Riders
    toss_decision                            field
    result                                  normal
    dl_applied                                   0
    winner                   Kolkata Knight Riders
    win_by_runs                                  0
    win_by_wickets                               4
    player_of_match                      SP Narine
    venue                             Eden Gardens
    umpire1                          C Shamshuddin
    umpire2                           A.D Deshmukh
    umpire3                                 S Ravi
    Name: 638, dtype: object




```python
IPL.iloc[IPL['win_by_wickets'].idxmax()]['winner']
```




    'Kolkata Knight Riders'



**Kolkata Knight Rider is Team which keeps the both record**

### 4.4 Which Team had won by (closest margin) minimum runs?
#### Overall & 2018


```python
IPL.iloc[IPL[IPL['win_by_runs'].ge(1)].win_by_runs.idxmin()]

```




    id                                                        59
    season                                                  2017
    city                                               Hyderabad
    date                                              2017-05-21
    team1                                         Mumbai Indians
    team2                                 Rising Pune Supergiant
    toss_winner                                   Mumbai Indians
    toss_decision                                            bat
    result                                                normal
    dl_applied                                                 0
    winner                                        Mumbai Indians
    win_by_runs                                                1
    win_by_wickets                                             0
    player_of_match                                    KH Pandya
    venue              Rajiv Gandhi International Stadium, Uppal
    umpire1                                             NJ Llong
    umpire2                                               S Ravi
    umpire3                                                  NaN
    Name: 58, dtype: object




```python
IPL2018.iloc[IPL[IPL['win_by_runs'].ge(1)].win_by_runs.idxmin()]

```




    id                                  7952
    season                              2018
    city                             Kolkata
    date                            25/05/18
    team1                Sunrisers Hyderabad
    team2              Kolkata Knight Riders
    toss_winner        Kolkata Knight Riders
    toss_decision                      field
    result                            normal
    dl_applied                             0
    winner               Sunrisers Hyderabad
    win_by_runs                           14
    win_by_wickets                         0
    player_of_match              Rashid Khan
    venue                       Eden Gardens
    umpire1                      Nitin Menon
    umpire2                 Kumar Dharmasena
    umpire3                   Anil Chaudhary
    Name: 694, dtype: object



**Overall Mumbai Indian Has won in 2017.
for 2018, SRH won by 14 Runs**

### 4.5 Which Team had won by minimum wickets?
#### Overall & 2018


```python
IPL.iloc[IPL[IPL['win_by_wickets'].ge(1)].win_by_wickets.idxmin()]
```




    id                                   560
    season                              2015
    city                             Kolkata
    date                          2015-05-09
    team1                    Kings XI Punjab
    team2              Kolkata Knight Riders
    toss_winner              Kings XI Punjab
    toss_decision                        bat
    result                            normal
    dl_applied                             0
    winner             Kolkata Knight Riders
    win_by_runs                            0
    win_by_wickets                         1
    player_of_match               AD Russell
    venue                       Eden Gardens
    umpire1                     AK Chaudhary
    umpire2                  HDPK Dharmasena
    umpire3                              NaN
    Name: 559, dtype: object




```python
IPL2018.iloc[IPL['win_by_wickets'].idxmin()]
```




    id                                7894
    season                            2018
    city                            Mumbai
    date                          07/04/18
    team1                   Mumbai Indians
    team2              Chennai Super Kings
    toss_winner        Chennai Super Kings
    toss_decision                    field
    result                          normal
    dl_applied                           0
    winner             Chennai Super Kings
    win_by_runs                          0
    win_by_wickets                       1
    player_of_match               DJ Bravo
    venue                 Wankhede Stadium
    umpire1                 Chris Gaffaney
    umpire2                A Nanda Kishore
    umpire3                 Anil Chaudhary
    Name: 636, dtype: object



**Kolkata Knight Riders and Chennai Super Kings have won by Narrowest margin in wickets**

### 4.6 Which Season had most matches?**


```python
plt.title('Matches in Each Season')
plt.xlabel('x')
plt.ylabel('y')

sns.countplot(x='season', data=IPL)
plt.show()
```


![png](output_66_0.png)


**Between 2011 & 2013 IPL had most matches. 2013 it had maximum**

### 4.7 Which City is most Popular in IPL
#### Overall & 2018


```python
data = IPL.city.value_counts()
sns.barplot(y = data.index, x = data, orient='h');
```


![png](output_69_0.png)



```python
fig=plt.figure(figsize=(10,12))
plt.subplot(polar=True)
sns.countplot(x='city',data=IPL2018, palette='gist_earth')
```




    <matplotlib.axes._subplots.PolarAxesSubplot at 0x1c17141ce80>




![png](output_70_1.png)


**Mumbai is clear distant Winner as far as popularity is concerned, Followed by Kolkata & Delhi.
in 2018, Mumbai & Kolkata was popular  city**

### 4.8 Which Stadium is getting Most Home Matches in IPL**


```python
data = IPL.venue.value_counts()
sns.barplot(y = data.index, x = data, orient='h');

```


![png](output_73_0.png)



```python
data = IPL2018.venue.value_counts()
sns.barplot(y = data.index, x = data, orient='h');

```


![png](output_74_0.png)


**Chennai, Chinnaswamy stadium is popular stadium followed by Eden Gardens, Kotla & Wankhede.**

### 4.9 Which Team is most successful in IPL**

Lets see, who has won the maximum matches in the dataset. We will count the winner and plot in graph


```python
data = IPL.winner.value_counts()
sns.barplot(y = data.index, x = data, orient='h');

```


![png](output_78_0.png)


**Mumbai indian comes distinctively as Top Successful Team Followed by Chennai Super Kings**


```python

```

### 4.10 Team Win Stats Standings YOY


```python
pd.crosstab(IPL.winner,IPL.season)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>season</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
      <th>2018</th>
    </tr>
    <tr>
      <th>winner</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Chennai Super Kings</th>
      <td>9</td>
      <td>8</td>
      <td>9</td>
      <td>11</td>
      <td>10</td>
      <td>12</td>
      <td>10</td>
      <td>10</td>
      <td>0</td>
      <td>0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Deccan Chargers</th>
      <td>2</td>
      <td>9</td>
      <td>8</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Delhi Daredevils</th>
      <td>7</td>
      <td>10</td>
      <td>7</td>
      <td>4</td>
      <td>11</td>
      <td>3</td>
      <td>2</td>
      <td>5</td>
      <td>7</td>
      <td>6</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Gujarat Lions</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>9</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Kings XI Punjab</th>
      <td>10</td>
      <td>7</td>
      <td>4</td>
      <td>7</td>
      <td>8</td>
      <td>8</td>
      <td>12</td>
      <td>3</td>
      <td>4</td>
      <td>7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Kochi Tuskers Kerala</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Kolkata Knight Riders</th>
      <td>6</td>
      <td>3</td>
      <td>7</td>
      <td>8</td>
      <td>12</td>
      <td>6</td>
      <td>11</td>
      <td>7</td>
      <td>8</td>
      <td>9</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Mumbai Indians</th>
      <td>7</td>
      <td>5</td>
      <td>11</td>
      <td>10</td>
      <td>10</td>
      <td>13</td>
      <td>7</td>
      <td>10</td>
      <td>7</td>
      <td>12</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Pune Warriors</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Rajasthan Royals</th>
      <td>13</td>
      <td>6</td>
      <td>6</td>
      <td>6</td>
      <td>7</td>
      <td>11</td>
      <td>7</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>7</td>
    </tr>
    <tr>
      <th>Rising Pune Supergiant</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Rising Pune Supergiants</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>Royal Challengers Bangalore</th>
      <td>4</td>
      <td>9</td>
      <td>8</td>
      <td>10</td>
      <td>8</td>
      <td>9</td>
      <td>5</td>
      <td>8</td>
      <td>9</td>
      <td>3</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Sunrisers Hyderabad</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>10</td>
      <td>6</td>
      <td>7</td>
      <td>11</td>
      <td>8</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
</div>



**From the above Table we see that Chennai Super Kings is most consistent Team w.r.t winning in each season is concerned**

### 4.11 Highest Win % Market Share in IPL


```python
import matplotlib.pyplot as plt
data = IPL.winner.value_counts()

plt.figure(figsize=(11,11)) #To Set Graph size

explode= (0.1,0,0,0,0,0,0,0,0,0,0,0,0,0)

plt.pie(data, explode=explode, counterclock=False, startangle=90, shadow='True', autopct='%.1f%%',pctdistance = 1.1)
plt.legend(data.index, loc="best", bbox_to_anchor = (1,1))
plt.axis('equal')
plt.title('IPL Win % Share')
plt.show()



```


![png](output_85_0.png)


**Mumbai Indian has highest Win% followed by Chennai Super Kings & Kolkata Knight Riders**


```python
fig1, ax1 = plt.subplots()
explode= (0.5,0,0,0,0,0,0,0,0,0,0,0,0,0)
ax1.pie(data, autopct='%1.1f%%', explode=explode, startangle=90)
#draw circle
centre_circle = plt.Circle((0,0),0.70,fc='white')
fig = plt.gcf()
fig.gca().add_artist(centre_circle)
# Equal aspect ratio ensures that pie is drawn as a circle
ax1.axis('equal')
plt.legend(data.index,loc='best')
plt.tight_layout()
plt.show()
```


![png](output_87_0.png)


### 4.12 Top player of the match Winners - Overall
**


```python
top_players = IPL.player_of_match.value_counts()[:8]

fig, ax = plt.subplots()
ax.set_ylim([0,22])
ax.set_ylabel("Count")
ax.set_title("Top player of the match Winners")
#top_players.plot.bar()
sns.barplot(x = top_players.index, y = top_players, orient='v'); #palette="Blues");
plt.show()
```


![png](output_89_0.png)


### 4.13 Top player of the match Winners - 2018 & 2017


```python
top_players1 = IPL2018.player_of_match.value_counts()[:7]

fig, ax = plt.subplots()
ax.set_ylim([0,5])
ax.set_ylabel("Count")
ax.set_title("2018 Top player of the match Winners")
#top_players.plot.bar()
sns.barplot(x = top_players1.index, y = top_players1, orient='v'); #palette="Blues");
plt.show()
```


![png](output_91_0.png)


### 4.13 Top player of the match Winners - 2017


```python
top_players3 = IPL2017.player_of_match.value_counts()[:7]

fig, ax = plt.subplots()
ax.set_ylim([0,4])
ax.set_ylabel("Count")
ax.set_title("2017 Top player of the match Winners")
#top_players.plot.bar()
sns.barplot(x = top_players3.index, y = top_players3, orient='v'); #palette="Blues");
plt.show()
```


![png](output_93_0.png)


**Overall Chris Gayle, Rohit Sharma, AB Devillers are legends, but one Needs to watch out Rashid Khan in 2019. He is emerging Icons of IPL**

### 4.14 Does Winning the Toss helps in Winning matches?**

How much Toss winning Matters?

Lets analyse the data when Toss Winner is also the Match winner. We will analyse all the matches and try to figure out if there is any corelation


```python

ss = IPL['toss_winner'] == IPL['winner']
ss.groupby(ss).size()

```




    False    339
    True     357
    dtype: int64




```python
import matplotlib.pyplot as plt

explode= (0.1,0)
colors=('r','g')
plt.pie(ss.groupby(ss).size(), explode= explode, colors=colors, counterclock=False, shadow ='True', startangle=45, autopct='%.1f%%')
plt.title('Toss Win')
plt.legend(ss, loc='best')
plt.show()
```


![png](output_98_0.png)


### 4.15 Did Choosing to Bat first or Field First helped in Toss winning**


```python
sns.countplot(IPL.toss_decision[IPL.toss_winner == IPL.winner])
plt.show()
```


![png](output_100_0.png)



```python
sns.countplot(IPL2018.toss_decision[IPL.toss_winner == IPL.winner])
plt.show()
```


![png](output_101_0.png)


**Overall & in 2018, one most chose to field first.**

### Winner is Toss Winner too - Overall


```python
pd.crosstab( IPL.winner , IPL.toss_winner).plot(kind = 'bar' , title = 'Winner is toss winner Too' , figsize=(18,7))

```




    <matplotlib.axes._subplots.AxesSubplot at 0x1c16f7c69e8>




![png](output_104_1.png)


**The above bar chart indicates Winner has the advantage more when they win toss. We will analyse now season by season**
**Mumbai Indian, CSK are the team who wins match, when they win toss**


### Which Team Chose What - On Winning the Toss


```python
pd.crosstab(IPL.winner,IPL.toss_decision).plot(kind='bar',title='Winning w.r.t toss decisions overall')

```




    <matplotlib.axes._subplots.AxesSubplot at 0x1c16fbc9668>




![png](output_107_1.png)


**The above data indicates that match Winner has mostly chosen to chase once won the toss. IPL provides edge to chasing.**
**KKR, Mumbai Indian, RCB & KingsXIPunjab Prefers to field first**

### 4.18  Analysing Impact of Toss Winning team Season By Season


```python

toss = IPL.groupby(['season', 'toss_winner']).winner.value_counts().reset_index(name = 'count')
toss['result'] = np.where(toss.toss_winner == toss.winner, 'won', 'lost')
toss_result = toss.groupby(['season', 'toss_winner','result'])['count'].sum().reset_index()

for x in range(2008, 2019, 1):
    toss_result_x = toss_result[toss_result['season'] == x]
    plot = sns.barplot(x="toss_winner", y="count", hue="result", data=toss_result_x)
    plot.set_title('Matches won/lost by teams winning toss \nSeason ' +str(x))
    plot.set_xticklabels(toss_result_x['toss_winner'],rotation=30)
    plt.show()
    x+=1
```


![png](output_110_0.png)



![png](output_110_1.png)



![png](output_110_2.png)



![png](output_110_3.png)



![png](output_110_4.png)



![png](output_110_5.png)



![png](output_110_6.png)



![png](output_110_7.png)



![png](output_110_8.png)



![png](output_110_9.png)



![png](output_110_10.png)


__Overall it has been seen that Winning the Toss helps in Winning the match. 2018 reconfirms the Trend__

### 4.19 Who is Most Trusted Umpires in IPL


```python
New_Data1 = IPL.loc[:, ['umpire1', 'umpire2']]
umpire1 = New_Data1['umpire1'].tolist()
umpire2 = New_Data1['umpire2'].tolist()
umpires = umpire1 + umpire2
from collections import Counter
c = Counter(umpires)
umpires = []
count = []
for i,j in c.most_common(10):
    umpires.append(i)
    count.append(j)


plt.gcf().set_size_inches(15,5)
plt.xlabel('Umpires')
plt.ylabel('Matches')
plt.title('Most Trusted IPL Umpire')
#plt.bar(umpires, count, color = 'mint' )
sns.barplot(count,umpires, palette="Blues_d")

plt.show()
```


![png](output_113_0.png)


**S Ravi is most trusted IPL umpires followed by Dharamsena & Shashuddin**

### 4.19 Which Venue did Weather Affected Most**



```python
sns.countplot(IPL.city[IPL.dl_applied==1])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x183f9bc7518>




![png](output_116_1.png)


**Kolkata has been unfortunate stadium where weather may have affected most. As IPL is played in April-May, weather gods are away and most matches have been unaffected**


### 4.21 Best Stadium to Chase and Win**


```python
IPL.venue[IPL.win_by_wickets!=0].mode()
```




    0    Eden Gardens
    dtype: object



### 4.20 Best Chasing Venues**


```python
sns.swarmplot(x='win_by_wickets', y='venue',data=IPL)
plt.show()
```


![png](output_121_0.png)


### 4.22 Best Team In Best Chasing Venue <Kolkata - Eden Gardens>


```python

#Winning Percent of teams at Eden Gardens
#BT_def1 = IPL[IPL.venue=='Eden Gardens']['winner']
#BT_def1.value_counts()

#BT_def1 = IPL[IPL.venue=='Eden Gardens']['winner'].value_counts(normalize=True)*100
#BT_def1.plot(kind = 'bar' , title='winning percent at Eden Gardens' , figsize = (7,7) , grid=True).legend(bbox_to_anchor=(1.2, 0.5))

df = IPL[IPL.venue=='Eden Gardens']['winner'].value_counts(normalize=True)*100
df.plot(kind = 'pie' , title = 'winning percent of teams at Eden Gardens' , 
        figsize = (7,7) , startangle=45, shadow='True', autopct='%.1f%%', grid = True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1c16c526f98>




![png](output_123_1.png)


**The Best Team is Kolkata Knight Riders at Eden Gardens, which is best Chasing Stadium. This also signals that Home team has clear advantage in home turf**

### 4.23 Best Stadium to Bat first and Win**



```python
IPL.venue[IPL.win_by_runs!=1].mode()
```




    0    M Chinnaswamy Stadium
    dtype: object



## 4.23 Best Defending Venue**


```python
sns.swarmplot(x='win_by_runs', y='venue', data=IPL)
plt.show()
```


![png](output_128_0.png)


**Best Defending Venue is Chinnaswamy Stadium Bangalore.**

### 4.24 Best Team In Best Defending Venue <Bangalore- Channaswamy Stadium>


```python

#Winning Percent of teams at Chinnaswamy Stadium
#BT_def1 = IPL[IPL.venue=='M Chinnaswamy Stadium']['winner']
#BT_def1.value_counts()

#BT_def1 = IPL[IPL.venue=='M Chinnaswamy Stadium']['winner'].value_counts(normalize=True)*100
#BT_def1.plot(kind = 'bar' , title='winning percent at Chinnaswamy' , figsize = (7,7) , grid=True).legend(bbox_to_anchor=(1.2, 0.5))

df = IPL[IPL.venue=='M Chinnaswamy Stadium']['winner'].value_counts(normalize=True)*100
df.plot(kind = 'pie' , title = 'winning percent of teams at Chinnaswamy' , 
        figsize = (7,7) , startangle=45, shadow='True', autopct='%.1f%%', grid = True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1c16c13deb8>




![png](output_131_1.png)


**The Best Team is Royal Challengers Bangalore in Chinnaswamy Stadium, which is best defending Stadium. This also again reconfirms that Home team has clear advantage in home turf**

### 4.25 Which Team is Best in Defending**


```python
IPL.winner[IPL.win_by_runs!=1].mode()
```




    0    Mumbai Indians
    dtype: object



### 4.25 MOSt Win by Batting first and Defending Total


```python
plt.figure(figsize=(5,12))
sns.swarmplot(x='win_by_runs',y='winner',data=IPL)
plt.show()
```


![png](output_136_0.png)


**Mumbai Indian is Top Team in defending, followed by CSK**

### 4.15 Which Team is Best in Chasing**


```python
IPL.winner[IPL.win_by_wickets!=0].mode()
```




    0    Kolkata Knight Riders
    dtype: object



### 4.25 MOSt Win by Bowling first and Fielding First Winner**


```python
plt.figure(figsize=(5,12))
sns.swarmplot(x='win_by_wickets',y='winner',data=IPL)
plt.show()
```


![png](output_141_0.png)


**CSK & KKR seems to be great chasers**

### 4.27 Home Turf Advantage - Team wins in home city vs other cities¶


**Each team plays two matches against the other teams, one in its home city and other in the home city of the opposite team. It would be interesting see if playing in home city increases a teams chances of a win.**


```python
#No of wins by team and season in each city
x, y = 2008, 2019
while x < y:
    wins_percity = IPL[IPL['season'] == x].groupby(['winner', 'city'])['id'].count().unstack()
    plot = wins_percity.plot(kind='bar', stacked=True, title="Team wins in different cities\nSeason "+str(x), figsize=(7, 5))
    sns.set_palette("Paired", len(IPL['city'].unique()))
    plot.set_xlabel("Teams")
    plot.set_ylabel("No of wins")
    plot.legend(loc='best', prop={'size':8})
    x+=1
```


![png](output_145_0.png)



![png](output_145_1.png)



![png](output_145_2.png)



![png](output_145_3.png)



![png](output_145_4.png)



![png](output_145_5.png)



![png](output_145_6.png)



![png](output_145_7.png)



![png](output_145_8.png)



![png](output_145_9.png)



![png](output_145_10.png)


**Overall, only few Team gets advantage of home matches, but many of them turn to be IPL Champions.
in 2018, Rajasthan Royal, Kolkata Knight Riders and Sunrisers Hyderabad are Top team in Home matches.**

## 5. Conclulsion


**We have completed detailed analysis, but there is still scope further deep analysis. We have observed following relevent conclusions.**

	- Mumbai is Popular Destination of IPL
	- Favourite Ground is Chinnaswamy Stadium Bangalore
	- The 2 Most successful Teams in IPL History are - Mumbai Indians & Chennai Super Kings.
	- Chennai Super Kings is Most Consistent Team 
	- Chris Gayle, Rohit Sharma & AB De Villers are Icons of IPLs
	- Rashid Khan is most Likely is emerging Icon
	- Toss Winning Matters. 51.3% Matches Won out of 696 by Toss Winner
	- Match Winners post winning the Toss, chose to Field First over Bat
	- KKR, Mumbai Indian, RCB & KingsXIPunjab Prefers to field first
	- S Ravi, Dharmasena & Shamshuddin have been entrusted with  Crucial Decision Taking role multiple time.
    - Kolkata most affected by weather, though numbers are insignificant.
	- Eden Garden has emerged as Best Chasing Venue in IPL History
	- Chinnaswamy Stadium of Bangalore has helped several Team in defending the Total Scored
	- It was proven that home turf gives advantage to home team, as RCB has won maximum in Bangalore Chinnaswamy Stadium
	- Mumbai Indians is Best Defender of Total in IPL, Followed by CSK
	- Kolkata Knight Rider is Best Chaser of Total in IPL.
	- Many Team got home turf advantage, out of them later on turned to be IPL champon later. These team got advantage -         2008 – RR & KingsXI  / 2010 – MI, KKR, CSK / 2011 – CSK/ 2012 – CSK / 2013 – CSK, RR, SRH / 2014 – CSK/ 2015 – MI,         KKR / 2016 – RCB / 2017 – Mumbai Indian / 2018 – SRH, RR, KKR 

# Thank You
